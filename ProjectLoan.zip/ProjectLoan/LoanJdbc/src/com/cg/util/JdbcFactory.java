package com.cg.util;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class JdbcFactory {
	private static Properties p;

	private JdbcFactory() {

	}

	static {
		p = new Properties();
		try {
			p.load(new FileReader("src/dbinfo.txt"));

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static Connection getConnection() throws SQLException {
		String url = p.getProperty("url");
		String user = p.getProperty("user");
		String pass = p.getProperty("pass");
		String driver = p.getProperty("driver");
		try {
			Class.forName(driver);
		} catch (ClassNotFoundException e) {
			throw new SQLException(e.getMessage());
		}
		Connection conn = DriverManager.getConnection(url, user, pass);
		return conn;
	}
}
