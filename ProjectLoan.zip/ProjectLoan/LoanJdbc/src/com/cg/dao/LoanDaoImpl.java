package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.cg.bean.Loan;
import com.cg.bean.LoanTransaction;
import com.cg.exception.LoanException;
import com.cg.util.JdbcFactory;

public class LoanDaoImpl implements LoanDao {
	
	@Override
	public void applyLoan(Loan loan) {
		String sql = "insert into loan values(?,?,?,?,?,?,?,?,?,?)";
		Connection conn = null;
		try {
			conn = JdbcFactory.getConnection();
			PreparedStatement stmt = conn.prepareStatement(sql);
			stmt.setString(1, loan.getActNo());
			stmt.setString(2, loan.getHolder());
			stmt.setString(3, loan.getMobileNo());
			stmt.setString(4, loan.getCity());
			stmt.setString(5, loan.getAadharNo());
			stmt.setDouble(6, loan.getSalary());
			stmt.setDouble(7, loan.getLoanAmount());
			stmt.setInt(8, loan.getTime());
			stmt.setDouble(9, loan.getInterestRate());
			stmt.setDouble(10, loan.getTotalAmount());
			stmt.execute();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (conn != null)
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
		}
	}

	@Override
	public String payEmi(String actNo, double amount, double emi) {
		String sql = "select * from loan where actNo=?";
		Connection conn= null;
		Loan loan= null;
		try {
			conn= JdbcFactory.getConnection();
			PreparedStatement stmt = conn.prepareStatement(sql);
			stmt.setString(1, actNo);
			ResultSet rs=stmt.executeQuery();
			if (rs.next()) {
				loan = new Loan();
				loan.setActNo(rs.getString(1));
				loan.setHolder(rs.getString(2));
				loan.setMobileNo(rs.getString(3));
				loan.setCity(rs.getString(4));
				loan.setAadharNo(rs.getString(5));
				loan.setSalary(rs.getDouble(6));
				loan.setLoanAmount(rs.getDouble(7));
				loan.setTime(rs.getInt(8));
				loan.setInterestRate(rs.getDouble(9));
				loan.setTotalAmount(rs.getDouble(10));
			}
			double balance = loan.getTotalAmount()-emi;
			System.out.println(balance);
			String sql4="update loan set totalAmount=? where actNo=?";
			PreparedStatement stmt3=conn.prepareStatement(sql4);
			stmt3.setDouble(1,balance);
			stmt3.setString(2,actNo);
			stmt3.executeUpdate();
			LoanTransaction trans=new LoanTransaction(loan.getActNo(),amount," Emi paid");
			String sql3="insert into loantransaction values(?,?,?)";
			PreparedStatement stmt2=conn.prepareStatement(sql3);
			stmt2.setString(1,trans.getActNo());
			stmt2.setDouble(2,trans.getEmiAmount());
			stmt2.setString(3,trans.getStatus());
			
			stmt2.execute();
		return "EmI amount is paid";
		
	}
		catch(SQLException e){
			e.printStackTrace();
			return null;
			
		}finally{
			if(conn!=null)
				try{
					conn.close();
					conn.close();
				}catch(SQLException e){
					e.printStackTrace();
				}
				}
		
		}

	@Override
	public double showBalance(String actNo) throws LoanException {
		String sql = "select * from loan where actNo=?";
		Connection conn= null;
		Loan loan= null;
		try {
			conn= JdbcFactory.getConnection();
			PreparedStatement stmt = conn.prepareStatement(sql);
       		stmt.setString(1, actNo);
			ResultSet rs=stmt.executeQuery();
			if (rs.next()) {
				loan = new Loan();
				loan.setActNo(rs.getString(1));
				loan.setHolder(rs.getString(2));
				loan.setMobileNo(rs.getString(3));
				loan.setCity(rs.getString(4));
				loan.setAadharNo(rs.getString(5));
				loan.setSalary(rs.getDouble(6));
				loan.setLoanAmount(rs.getDouble(7));
				loan.setTime(rs.getInt(8));
				loan.setInterestRate(rs.getDouble(9));
				loan.setTotalAmount(rs.getDouble(10));
			}
			
		return loan.getTotalAmount();
		
	}
		catch(SQLException e){
			e.printStackTrace();
			
			
		}finally{
			if(conn!=null)
				try{
					conn.close();
					conn.close();
				}catch(SQLException e){
					e.printStackTrace();
				}
				}
		return 0;
		}
		

	@Override
	public String foreClose(String actNo) throws LoanException {
		
		String sql = "select * from loan where actNo=?";
		Connection conn= null;
		Loan loan= null;
		try {
			conn= JdbcFactory.getConnection();
			PreparedStatement stmt = conn.prepareStatement(sql);
			stmt.setString(1, actNo);
			ResultSet rs=stmt.executeQuery();
			if (rs.next()) {
				loan = new Loan();
				loan.setActNo(rs.getString(1));
				loan.setHolder(rs.getString(2));
				loan.setMobileNo(rs.getString(3));
				loan.setCity(rs.getString(4));
				loan.setAadharNo(rs.getString(5));
				loan.setSalary(rs.getDouble(6));
				loan.setLoanAmount(rs.getDouble(7));
				loan.setTime(rs.getInt(8));
				loan.setInterestRate(rs.getDouble(9));
				loan.setTotalAmount(rs.getDouble(10));
			}
			double totalamount=loan.getTotalAmount();
			loan.setTotalAmount(0);
		return "Loan ForeClosed";
	}
		catch(SQLException e){
			e.printStackTrace();
			
			
		}finally{
			if(conn!=null)
				try{
					conn.close();
					conn.close();
				}catch(SQLException e){
					e.printStackTrace();
				}
				}
		return null;
		
		}
		
	

	@Override
	public Loan getLoanDetails(String actNo) {
		String sql = "select * from loan where actNo=actNo";
		Connection conn = null;
		Loan loan = null;
		try {
			conn = JdbcFactory.getConnection();
			Statement stmt = conn.createStatement();
//			stmt.setString(1, actNo);
			ResultSet rs = stmt.executeQuery(sql);

			if (rs.next()) {
				loan = new Loan();
				loan.setActNo(rs.getString(1));
				loan.setHolder(rs.getString(2));
				loan.setMobileNo(rs.getString(3));
				loan.setCity(rs.getString(4));
				loan.setAadharNo(rs.getString(5));
				loan.setSalary(rs.getDouble(6));
				loan.setLoanAmount(rs.getDouble(7));
				loan.setTime(rs.getInt(8));
				loan.setInterestRate(rs.getDouble(9));
				loan.setTotalAmount(rs.getDouble(10));
			}
			return loan;

		} catch (SQLException e) {
			e.printStackTrace();
			return null;

		} finally {
			if (conn != null)
				try {
					conn.close();
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
		}

	}

	@Override
	public List<LoanTransaction> transactions(String actNo) {
		List<LoanTransaction> loantransaction=new ArrayList<>();
	      String sql="select * from Loantransaction where actNo=actNo";
	      Connection conn=null;
	      
	      try {
			conn=JdbcFactory.getConnection();
			Statement stmt2=conn.createStatement();
//			stmt2.setString(1,actNo);
			ResultSet rs=stmt2.executeQuery(sql);
			 ResultSet rs1=conn.createStatement().executeQuery(sql);
			  while(rs1.next())
			  {
				  LoanTransaction transaction= new LoanTransaction();
				  
				  transaction.setActNo(rs1.getString(1));
				  transaction.setEmiAmount(rs1.getInt(2));
				  
				  loantransaction.add(transaction);
			  }
		return loantransaction;
	}catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		return null;
	}
      finally{
    	  try {
			if(conn!=null)
				  conn.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
      }
	}
}