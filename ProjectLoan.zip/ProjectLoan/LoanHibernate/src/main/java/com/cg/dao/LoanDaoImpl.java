package com.cg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.cg.entity.Loan;
import com.cg.entity.LoanTransaction;
import com.cg.exception.LoanException;

public class LoanDaoImpl implements LoanDao{
	
	private List<LoanTransaction> trans;

	@Override
	public void applyLoan(Loan loan) {
		EntityManagerFactory emf =Persistence.createEntityManagerFactory("Oracle");
		EntityManager em = emf.createEntityManager();
		EntityTransaction txn =em.getTransaction();
		txn.begin();
		LoanTransaction trans = new LoanTransaction(loan.getActNo(),"LoanApplied");
		loan.getTransactions().add(trans);
		em.persist(loan);
		txn.commit();
		em.close();
		emf.close();
		
		
	}

	@Override
	public String payEmi(String actNo, double totalAmount, double emi) {
		EntityManagerFactory emf =Persistence.createEntityManagerFactory("Oracle");
		EntityManager em = emf.createEntityManager();
		EntityTransaction txn =em.getTransaction();
		txn.begin();
		Loan loan =em.find(Loan.class,actNo);
		
	  double balance= loan.getTotalAmount()-emi;
		loan.setTotalAmount(balance);
		LoanTransaction trans = new LoanTransaction(loan.getActNo(),"Emi Paid");
		loan.getTransactions().add(trans);
		em.persist(loan);
		
		txn.commit();
		return "Emi Payed";
	}

	@Override
	public double showBalance(String actNo) throws LoanException {
		EntityManagerFactory emf =Persistence.createEntityManagerFactory("Oracle");
		EntityManager em = emf.createEntityManager();
		
		Loan loan =em.find(Loan.class,actNo);
		
		return loan.getTotalAmount();
		
		
	}

	@Override
	public String foreClose(String actNo) throws LoanException {
		EntityManagerFactory emf =Persistence.createEntityManagerFactory("Oracle");
		EntityManager em = emf.createEntityManager();
		EntityTransaction txn =em.getTransaction();
		txn.begin();
		Loan loan =em.find(Loan.class,actNo);
		loan.setTotalAmount(0);
		LoanTransaction trans = new LoanTransaction(loan.getActNo(),"Loan forclosed");
		loan.getTransactions().add(trans);
		txn.commit();
		return "Loan Foreclosed";
	}

	@Override
	public Loan getLoanDetails(String actNo) {
		EntityManagerFactory emf =Persistence.createEntityManagerFactory("Oracle");
		EntityManager em = emf.createEntityManager();
		EntityTransaction txn =em.getTransaction();
		Loan loan = em.find(Loan.class,actNo);
		return loan;
	}
	
}