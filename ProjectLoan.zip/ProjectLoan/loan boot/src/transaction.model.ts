
export class Transaction {
    txnId: number;
    accountNumber: string;
    action:string;
}