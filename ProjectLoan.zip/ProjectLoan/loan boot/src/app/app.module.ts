import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms'

import { AppComponent } from './app.component';
import { ApplyloanComponent } from './applyloan/applyloan.component';
import { CalculateEmiComponent } from './calculate-emi/calculate-emi.component';
import { TransactionsComponent } from './transactions/transactions.component';
import { LoanRoutingModule } from './loan-routing.module';
import {HttpClientModule} from "@angular/common/http";
import { DisplayComponent } from './display/display.component';



@NgModule({
  declarations: [
    AppComponent,
    ApplyloanComponent,
    CalculateEmiComponent,
    TransactionsComponent,
    DisplayComponent
  ],
  imports: [
    BrowserModule,
    LoanRoutingModule,FormsModule,HttpClientModule
  
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
