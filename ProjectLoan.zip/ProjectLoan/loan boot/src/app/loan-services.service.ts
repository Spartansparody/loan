import { Injectable } from '@angular/core';
import { LoanModel } from './loan.model';

import {HttpClientModule, HttpClient} from "@angular/common/http";
import { Transaction } from 'src/transaction.model';


@Injectable({
  providedIn: 'root'
})
export class LoanServicesService {
 loans:LoanModel[];
 baseUrl: string = 'http://localhost:8080/abcbank/loan/';
constructor(private http:HttpClient){}
 
 getLoans() {
    return this.http.get<LoanModel[]>(this.baseUrl + 'getAllLoans');

  }

  
createLoan(loan: LoanModel)
 {
    return this.http.post(this.baseUrl + 'applyLoan', loan);
  }

 
 updateLoan(loan: LoanModel) 
{
    return this.http.put(this.baseUrl + loan.accountNo, loan);
  }
  
  calculate_emi(loanamount:number,interest:number,tenuretime:number)
  {
    return this.http.get(this.baseUrl+'emi');
  }


payEmi(loan: LoanModel) 
{
    return this.http.put<LoanModel>(this.baseUrl + 'payEmi/' + loan.accountNo , loan);
  }

 
 forceLoanClose(loan: LoanModel) 
{
    return this.http.put<LoanModel>(this.baseUrl + 'forceclose/' + loan.accountNo , loan);
  }

 
 printTransactions()
 {
    return this.http.get<Transaction[]>(this.baseUrl + 'getAllLoanTransactions');
  }
  
}


 

