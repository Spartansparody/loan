import { Component, OnInit } from '@angular/core';
import { LoanServicesService } from '../loan-services.service';
import { LoanRoutingModule } from '../loan-routing.module';

@Component({
  selector: 'app-calculate-emi',
  templateUrl: './calculate-emi.component.html',
  styleUrls: ['./calculate-emi.component.css']
})
export class CalculateEmiComponent implements OnInit {
loanamount:number;
interest:number;
tenuretime:number;
calculate:number;  
constructor(private service:LoanServicesService) { }

  ngOnInit() {
  }
  calculate_emi()
  {
    this.service.calculate_emi(this.loanamount,this.interest,this.tenuretime);
  }

}
