package com.cg.dao;

import java.util.List;

import com.cg.bean.Loan;
import com.cg.bean.LoanTransaction;
import com.cg.exception.LoanException;

public interface LoanDao {

	void applyLoan(Loan loan);

	// int calculateEmi(double loanAmount,double interestRate,int time );

	String payEmi(String actNo, double totalAmount, double emi);

	double showBalance(String actNo) throws LoanException;

	String foreClose(String actNo) throws LoanException;

	Loan getLoanDetails(String actNo);
	 
	List<LoanTransaction> transactions(String actNo);
	
	
	
}
