import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {RouterModule,Routes} from '@angular/router'
import { ApplyloanComponent } from './applyloan/applyloan.component';
import { CalculateEmiComponent } from './calculate-emi/calculate-emi.component';
import { TransactionsComponent } from './transactions/transactions.component';
import { DisplayComponent } from './display/display.component';

const routes: Routes = [
  {path:'apply',component:ApplyloanComponent},
  {path:'emi',component:CalculateEmiComponent},
  {path:'display',component:DisplayComponent},
  {path:'print',component:TransactionsComponent},
  {path:'*',component:ApplyloanComponent}
];

@NgModule({
  imports: [
    CommonModule,RouterModule.forRoot(routes)

  ],
  declarations: [],
  exports:[RouterModule]


})
export class LoanRoutingModule { }
