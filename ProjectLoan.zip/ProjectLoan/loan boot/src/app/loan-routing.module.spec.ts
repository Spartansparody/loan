import { LoanRoutingModule } from './loan-routing.module';

describe('LoanRoutingModule', () => {
  let loanRoutingModule: LoanRoutingModule;

  beforeEach(() => {
    loanRoutingModule = new LoanRoutingModule();
  });

  it('should create an instance', () => {
    expect(loanRoutingModule).toBeTruthy();
  });
});
