package com.cg.entity;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="loans")
public class Loan {
	@Id

	private String actNo;
	private String holder;
	private String mobileNo;
	private String city;
	private String aadharNo;
	private double salary;
	private double loanAmount;
	private int time;
	private double interestRate;
	private double totalAmount;
	
	@OneToMany(fetch=FetchType.EAGER,cascade=CascadeType.ALL)
	Set<LoanTransaction> transactions = new HashSet<LoanTransaction>();
	
	

	
	
	
	public Loan(String actNo, String holder, String mobileNo, String city, String aadharNo, double salary,
			double loanAmount, int time, double interestRate, double totalAmount) {
		super();
		this.actNo = actNo;
		this.holder = holder;
		this.mobileNo = mobileNo;
		this.city = city;
		this.aadharNo = aadharNo;
		this.salary = salary;
		this.loanAmount = loanAmount;
		this.time = time;
		this.interestRate = interestRate;
		this.totalAmount = totalAmount;
		
	}
	public Set<LoanTransaction> getTransactions() {
		return transactions;
	}
	public void setTransactions(Set<LoanTransaction> transactions) {
		this.transactions = transactions;
	}
	public String getActNo() {
		return actNo;
	}
	public void setActNo(String actNo) {
		this.actNo = actNo;
	}
	public String getHolder() {
		return holder;
	}
	public void setHolder(String holder) {
		this.holder = holder;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getAadharNo() {
		return aadharNo;
	}
	public void setAadharNo(String aadharNo) {
		this.aadharNo = aadharNo;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public double getLoanAmount() {
		return loanAmount;
	}
	public void setLoanAmount(double loanAmount) {
		this.loanAmount = loanAmount;
	}
	public int getTime() {
		return time;
	}
	public void setTime(int time) {
		this.time = time;
	}
	public double getInterestRate() {
		return interestRate;
	}
	public void setInterestRate(double interestRate) {
		this.interestRate = interestRate;
	}
	public double getTotalAmount() {
		return totalAmount;
	}
	public void setTotalAmount(double totalAmount) {
		this.totalAmount = totalAmount;
	}
	
	
	
	
	
	
	
	
	

}
