package com.cg.entity;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="trans")
public class LoanTransaction {
	@Id
	@GeneratedValue
	private int txnNo;
	
	private String status;
	
	
	
	@JoinColumn(name = "actNo")
	private String actNo;
	
	
	
	public LoanTransaction(String actNo, String status) {
		this.actNo=actNo;
		this.status= status;
	}
	
	
	public int getTxnNo() {
		return txnNo;
	}


	public void setTxnNo(int txnNo) {
		this.txnNo = txnNo;
	}


	public String getActNo() {
		return actNo;
	}


	public void setActno(String actNo) {
		this.actNo = actNo;
	}


	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	
	
	

}
