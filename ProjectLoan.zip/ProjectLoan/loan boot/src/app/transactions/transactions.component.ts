import { Component, OnInit } from '@angular/core';
import { TransactionModel } from '../transaction.model';
import { LoanServicesService } from '../loan-services.service';
import { LoanRoutingModule } from '../loan-routing.module';

@Component({
  selector: 'app-transactions',
  templateUrl: './transactions.component.html',
  styleUrls: ['./transactions.component.css']
})
export class TransactionsComponent implements OnInit {
trans:TransactionModel[];
  constructor(private service:LoanServicesService) { }

  ngOnInit() {
  this.service.printTransactions().subscribe( data => {
    this.trans = data;
  });

  }
}
