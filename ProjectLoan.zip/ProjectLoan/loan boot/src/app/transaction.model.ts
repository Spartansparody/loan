
export class TransactionModel {
    txnId: number;
    accountNumber: string;
    action:string;
}