export class LoanModel{
    public name:string;
    public accountNo:string;
    public loantype:string;
	public loanAmount:number;
	public tenureInYears:number;
	public age:number;
	public phoneNo:string;
	public interest: number;
	public totalpayableAmount:number;
}