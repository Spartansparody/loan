import { Component, OnInit } from '@angular/core';
import { LoanModel } from '../loan.model';
import { Router } from '@angular/router';
import { LoanServicesService } from '../loan-services.service';

@Component({
  selector: 'app-display',
  templateUrl: './display.component.html',
  styleUrls: ['./display.component.css']
})
export class DisplayComponent implements OnInit {
  loans: LoanModel[];

  constructor(private router: Router, 
    private loanService: LoanServicesService,
  ) { }


  ngOnInit() {
  
  this.loanService.getLoans().subscribe( data => {
        this.loans = data;
    
  });
  }
 
 
  addLoan(): void {
 
   this.router.navigate(['add-loan']);

  };

  
showBalance(loan: LoanModel): number {
 
   var ans=confirm('Current Balance :: ?');
   if(ans=true)
   {
    return loan.totalpayableAmount;
   }
  
}

  
payEmi(loan: LoanModel) {

    var ans= confirm("Are you want to pay emi?")
    if(ans=true){
 return this.loanService.payEmi(loan);
    }
  
 
  }


  forceLoanClose(loan: LoanModel) {
    var ans= confirm("Are you want to Foreclose?")
    if(ans=true){
 return this.loanService.forceLoanClose(loan);
    }
 
  } 
 

  printTransactions() {
   
 this.router.navigate(['print']);
  }
}
