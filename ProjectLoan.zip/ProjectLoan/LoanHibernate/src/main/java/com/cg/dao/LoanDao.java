package com.cg.dao;

import com.cg.entity.Loan;
import com.cg.exception.LoanException;

public interface LoanDao {
	
	void applyLoan(Loan loan);
    
	//int calculateEmi(double loanAmount,double interestRate,int time );
	
	String payEmi(String actNo,double totalAmount,double emi);
	
	double showBalance(String actNo) throws LoanException;
	
	String foreClose(String actNo)throws LoanException;
	
	Loan getLoanDetails(String actNo);
}
	
	


