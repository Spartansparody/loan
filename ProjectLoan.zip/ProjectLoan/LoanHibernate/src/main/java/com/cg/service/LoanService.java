package com.cg.service;

import java.util.List;


import com.cg.entity.Loan;
import com.cg.entity.LoanTransaction;
import com.cg.exception.LoanException;

public interface LoanService {


	void applyLoan(Loan loan);
     
	double calculateEmi(double loanAmount,double interestRate,int time );
	
	String payEmi(String actNo);
	
	double showBalance(String actNo)throws LoanException;
	
	String foreClose(String actNo)throws LoanException;
	
	List<LoanTransaction> transactions(String actNo);
	
}
