package com.cg.service;

import java.util.List;

import com.cg.bean.Loan;
import com.cg.bean.LoanTransaction;
import com.cg.exception.LoanException;

public interface LoanService {
	void applyLoan(Loan loan);
    
	double calculateEmi(double loanAmount,double interestRate,int time );
	
	String payEmi(String actNo);
	
	double showBalance(String actNo)throws LoanException;
	
	String foreClose(String actNo)throws LoanException;
	
	
	
	
	
	

}
