
package com.cg.ui;

import java.util.Scanner;


import com.cg.bean.Loan;
import com.cg.exception.LoanException;
import com.cg.service.LoanServiceImpl;
import com.cg.validation.ValidationImpl;

public class LoanClient {

	public static void main(String[] args) throws LoanException {
		LoanServiceImpl l = new LoanServiceImpl();
		ValidationImpl valid = new ValidationImpl();
		Scanner sc = new Scanner(System.in);

		System.out.println("1.add");
		while (true) {
			System.out.println("enter choice:");
			int choice = sc.nextInt();
			switch (choice) {
			case 1:
				while (true) {
					System.out.println("Enter actNo:");
					String actNo = sc.next();
					if (valid.actNo(actNo)) {
						System.out.println("enter holder");
						String holder = sc.next();
						if (valid.validholder(holder)) {
							System.out.println("Enter salary:");
							double sal = sc.nextDouble();
							if (valid.sal(sal)) {
								System.out.println("Enter mobile no:");
								String mob = sc.next();
								if (valid.validMobNo(mob)) {
									System.out.println("Enter aadhar:");
									String aadhar = sc.next();
									if (valid.aadhNo(aadhar)) {
										System.out.println("Enter city:");
										String city = sc.next();
										System.out.println("loanamount:");
										double loanAmount = sc.nextDouble();
										System.out.println("time:");
										int time = sc.nextInt();
										System.out.println("interestRate:");
										double interestRate = sc.nextDouble();
										double totalAmount = 0;

										Loan loan = new Loan(actNo, holder, mob, city, aadhar, sal, loanAmount, time,
												interestRate, totalAmount);
										l.applyLoan(loan);
										System.out.println("added");
										break;
									}
								}
							}

						}
					}
				}
			case 2:

				System.out.println("Enter actno ");

				 String actNo = sc.next();

				System.out.println(l.payEmi(actNo));

				break;

			case 3:
				System.out.println("enter loan amount");
				double loanAmount = sc.nextDouble();
				System.out.println("time:");
				int time = sc.nextInt();
				System.out.println("enter interestrate:");
				double interestRate = sc.nextDouble();
				double emi = l.calculateEmi(loanAmount, interestRate, time);
				System.out.println(emi);
				break;
			case 4:
				try {
					System.out.println("enter account No: ");
					actNo = sc.next();

					System.out.println(l.showBalance(actNo));
				} catch (LoanException e) {
					// TODO Auto-generated catch block
					System.out.println(e);
				}
				break;
			case 5:
				try {

					System.out.println("enter account No:");
					actNo = sc.next();

					System.out.println(l.foreClose(actNo));
				} catch (LoanException e) {
					// TODO Auto-generated catch block
					System.out.println(e);
				}
				break;
//			case 6:
//				System.out.println("Enter account Number:");
//				actNo = sc.next();
//				for(int i=0;i<l.transactions(actNo).size();i++)
//				{
//					System.out.println(l.transactions(actNo).get(i));
//				}

			}

		}

	}
}
