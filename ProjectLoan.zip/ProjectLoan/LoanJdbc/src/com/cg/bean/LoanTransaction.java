package com.cg.bean;

public class LoanTransaction {

	private String actNo;

	private double emiAmount;
	private String status;

	public LoanTransaction() {
		// TODO Auto-generated constructor stub
	}

	public LoanTransaction(String actNo, double emiAmount, String status) {
		super();

		this.actNo = actNo;
		this.emiAmount = emiAmount;
		this.status = status;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getActNo() {
		return actNo;
	}

	public void setActNo(String actNo) {
		this.actNo = actNo;
	}

	public double getEmiAmount() {
		return emiAmount;
	}

	public void setEmiAmount(double emiAmount) {
		this.emiAmount = emiAmount;
	}

	@Override
	public String toString() {
		return "LoanTransaction [actNo=" + actNo + ", emiAmount=" + emiAmount + "]";
	}
}
