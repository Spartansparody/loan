import { Component, OnInit } from '@angular/core';
import { LoanModel } from '../loan.model';
import { LoanServicesService } from '../loan-services.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-applyloan',
  templateUrl: './applyloan.component.html',
  styleUrls: ['./applyloan.component.css']
})
export class ApplyloanComponent implements OnInit {

  loan:LoanModel;

  constructor(private service:LoanServicesService,private router:Router) {
    this.loan = new LoanModel;
   }

addLoan(){
  this.service.createLoan(this.loan).subscribe( data => {
    this.loan = new LoanModel();
    
  });
  this.router.navigate(['display']);
  
}
  ngOnInit() {
  }

}
