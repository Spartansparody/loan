package com.cg.service;

import java.util.List;

import com.cg.bean.Loan;
import com.cg.bean.LoanTransaction;
import com.cg.dao.LoanDao;
import com.cg.dao.LoanDaoImpl;
import com.cg.exception.LoanException;



public class LoanServiceImpl implements LoanService {
    LoanDao dao;
   
    public LoanServiceImpl() {
    	dao= new LoanDaoImpl();
    }
	@Override
	public void applyLoan(Loan loan) {
		// TODO Auto-generated method stub
		double emi=calculateEmi(loan.getLoanAmount(),loan.getInterestRate(),loan.getTime());
		double total=emi*loan.getTime()*12;
		loan.setTotalAmount(total);
		dao.applyLoan(loan);	
	}

	@Override
	public double calculateEmi(double loanAmount, double interestRate, int time) {
		double emi;
		  interestRate=interestRate/(12*100); 
		  
	        time=time*12; 
	            
	         emi= (loanAmount*interestRate*Math.pow(1+interestRate,time))/(Math.pow(1+interestRate,time)-1);
		return emi;
	}

	@Override
	public String payEmi(String actNo) {
		double loanAmount=dao.getLoanDetails(actNo).getLoanAmount();
		double interestRate=dao.getLoanDetails(actNo).getInterestRate();
		int time = dao.getLoanDetails(actNo).getTime();
		double emi = calculateEmi(loanAmount, interestRate, time);
		double amount = dao.getLoanDetails(actNo).getTotalAmount();
		
		
		return dao.payEmi(actNo,amount,emi);
	}

	@Override
	public double showBalance(String actNo) throws LoanException {
		
		
		if(actNo!=null)
		{
			return dao.showBalance(actNo);
		}
		else {
			throw new LoanException("Invalid account number:");
		}
	}

	@Override
	public String foreClose(String actNo) throws LoanException {
		// TODO Auto-generated method stub
		if(actNo!=null) {
		return dao.foreClose(actNo);
	}
		else {
			throw new LoanException("Invalid Account Number");
		}
	
}
	
}
